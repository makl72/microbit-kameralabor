// swift-tools-version: 5.9
import PackageDescription
import AppleProductTypes
let package = Package(
    name: "Kameralabor",
    platforms: [.iOS("16.0")],
    products: [.iOSApplication(name: "Kameralabor", targets: ["AppModule"], bundleIdentifier: "de.kameralabor.microbit", teamIdentifier: "", displayVersion: "0.1", bundleVersion: "1", appIcon: .placeholder(icon: .camera), accentColor: .presetColor(.yellow), supportedDeviceFamilies: [.pad], supportedInterfaceOrientations: [.portrait, .landscapeLeft, .landscapeRight], additionalInfoPlistContentFilePath: "Info.plist")],
    targets: [.executableTarget(name: "AppModule")]
)
