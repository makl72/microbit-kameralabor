import SwiftUI
import WebKit
import CoreBluetooth

@main struct KameralaborApp: App {
    var body: some Scene { WindowGroup { LaboratoryView() } }
}

private let serviceID = CBUUID(string: "6E400001-B5A3-F393-E0A9-E50E24DCCA9E")
private let txID = CBUUID(string: "6E400002-B5A3-F393-E0A9-E50E24DCCA9E")
private let rxID = CBUUID(string: "6E400003-B5A3-F393-E0A9-E50E24DCCA9E")

final class MicrobitRadio: NSObject, ObservableObject, CBCentralManagerDelegate, CBPeripheralDelegate {
    @Published var choices: [CBPeripheral] = []
    @Published var choosing = false
    private var central: CBCentralManager?
    private var peripheral: CBPeripheral?
    private var rx: CBCharacteristic?
    private var tx: CBCharacteristic?
    private var buffer = ""
    var event: ((String, String) -> Void)?

    override init() { super.init() }
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state == .poweredOn, choosing { central.scanForPeripherals(withServices: nil) }
        else if central.state != .poweredOn { event?("error", "Bluetooth am iPad einschalten.") }
    }
    func start() {
        choices = []; choosing = true
        if central == nil { central = CBCentralManager(delegate: self, queue: .main); return }
        if central?.state == .poweredOn { central?.scanForPeripherals(withServices: nil) }
        else if central?.state != .unknown { event?("error", "Bluetooth am iPad einschalten."); choosing = false }
    }
    func centralManager(_ central: CBCentralManager, didDiscover device: CBPeripheral, advertisementData: [String: Any], rssi RSSI: NSNumber) {
        let name = device.name ?? advertisementData[CBAdvertisementDataLocalNameKey] as? String ?? ""
        if name.hasPrefix("BBC micro:bit"), !choices.contains(where: { $0.identifier == device.identifier }) { choices.append(device) }
    }
    func select(_ device: CBPeripheral) {
        central?.stopScan(); choosing = false; peripheral = device
        device.delegate = self; central?.connect(device)
    }
    func disconnect() {
        central?.stopScan(); choosing = false; rx = nil; tx = nil; buffer = ""
        if let peripheral { central?.cancelPeripheralConnection(peripheral) }
        peripheral = nil
    }
    func centralManager(_ central: CBCentralManager, didConnect device: CBPeripheral) {
        device.discoverServices([serviceID])
    }
    func centralManager(_ central: CBCentralManager, didFailToConnect device: CBPeripheral, error: Error?) {
        event?("error", error?.localizedDescription ?? "Verbindung fehlgeschlagen.")
    }
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral device: CBPeripheral, error: Error?) {
        rx = nil; tx = nil; event?("disconnected", "")
    }
    func peripheral(_ device: CBPeripheral, didDiscoverServices error: Error?) {
        guard let service = device.services?.first(where: { $0.uuid == serviceID }) else {
            event?("error", "Bluetooth-UART fehlt. Kameralabor-Startprogramm aufspielen und den micro:bit neu starten.")
            disconnect(); return
        }
        device.discoverCharacteristics([txID, rxID], for: service)
    }
    func peripheral(_ device: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        tx = service.characteristics?.first(where: { $0.uuid == txID })
        rx = service.characteristics?.first(where: { $0.uuid == rxID })
        guard let tx, rx != nil else { event?("error", "Bluetooth-UART ist unvollständig."); disconnect(); return }
        device.setNotifyValue(true, for: tx)
    }
    func peripheral(_ device: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        if characteristic.isNotifying { event?("ready", "") }
        else { event?("error", error?.localizedDescription ?? "Antwortkanal fehlt."); disconnect() }
    }
    func write(_ value: String) {
        guard let device = peripheral, let rx, let data = value.data(using: .utf8) else { event?("error", "Nicht verbunden."); return }
        let mode: CBCharacteristicWriteType = rx.properties.contains(.write) ? .withResponse : .withoutResponse
        if data.count > 20 { event?("error", "Befehl zu lang."); return }
        device.writeValue(data, for: rx, type: mode)
    }
    func peripheral(_ device: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        guard error == nil, let data = characteristic.value, let text = String(data: data, encoding: .utf8) else { return }
        buffer += text
        while let newline = buffer.firstIndex(of: "\n") {
            let line = String(buffer[..<newline]).trimmingCharacters(in: .whitespacesAndNewlines)
            buffer = String(buffer[buffer.index(after: newline)...])
            event?("line", line)
        }
        if buffer.count > 128 { buffer = "" }
    }
}

struct LaboratoryView: View {
    @StateObject private var radio = MicrobitRadio()
    @State private var opened = false
    var body: some View {
        Group {
            if opened { LaboratoryWeb(radio: radio) }
            else { VStack(spacing: 24) {
                Text("micro:bit Kameralabor").font(.largeTitle.bold())
                Text("iPad-Testversion 2 · Kamera und Bluetooth")
                Button("Kameralabor öffnen") { opened = true }.buttonStyle(.borderedProminent)
            }.padding() }
        }
            .sheet(isPresented: $radio.choosing) {
                NavigationStack {
                    List(radio.choices, id: \.identifier) { device in
                        Button(device.name ?? "micro:bit") { radio.select(device) }
                    }
                    .navigationTitle("micro:bit wählen")
                    .toolbar { Button("Abbrechen") { radio.event?("error", "Auswahl abgebrochen."); radio.disconnect() } }
                }
            }
    }
}

struct LaboratoryWeb: UIViewRepresentable {
    let radio: MicrobitRadio
    func makeCoordinator() -> Coordinator { Coordinator(radio: radio) }
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.userContentController.add(context.coordinator, name: "microbit")
        let web = WKWebView(frame: .zero, configuration: config)
        context.coordinator.web = web
        radio.event = { [weak web] type, value in
            guard let web else { return }
            let detail = ["type": type, "value": value]
            guard let data = try? JSONSerialization.data(withJSONObject: detail), let json = String(data: data, encoding: .utf8) else { return }
            web.evaluateJavaScript("window.dispatchEvent(new CustomEvent('microbit-native',{detail:\(json)}))")
        }
        web.load(URLRequest(url: URL(string: "https://microbit-kameralabor.makl72.chatgpt.site/")!))
        return web
    }
    func updateUIView(_ web: WKWebView, context: Context) {}
    final class Coordinator: NSObject, WKScriptMessageHandler {
        let radio: MicrobitRadio
        weak var web: WKWebView?
        init(radio: MicrobitRadio) { self.radio = radio }
        func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.frameInfo.isMainFrame, message.frameInfo.request.url?.host == "microbit-kameralabor.makl72.chatgpt.site", let command = message.body as? [String: String], let op = command["op"] else { return }
            switch op {
            case "connect": radio.start()
            case "disconnect": radio.disconnect()
            case "write": if let value = command["value"] { radio.write(value) }
            default: break
            }
        }
    }
}
